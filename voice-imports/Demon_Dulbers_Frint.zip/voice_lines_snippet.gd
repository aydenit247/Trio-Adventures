# For godot/scripts/voice_lines.gd. Files are WAV; the game expects MP3 in res://assets/voices/<group>/ (convert first, or hand the zip to Claude).
	"You had called?": "mattias/mattias_you_had_called",
	"NOBODY LEAVES METOCY MART. NO REFUNDS. NO EXCHANGES.": "dulbers_demon/dulbers_demon_nobody_leaves_metocy_mart_no_refunds_no",
	"Ugh… fine… the REAL metocy… is past the mountain pass…": "dulbers_demon/dulbers_demon_ugh_fine_the_real_metocy_is_past_the_mou",
	"…but nobody gets past the giant.": "dulbers_demon/dulbers_demon_but_nobody_gets_past_the_giant",
	"*echoing* Impressive, my beloved trio. Come closer…": "mattias/mattias_impressive_my_beloved_trio_come_closer",
	"My beloved trio. I've came to tell you, you must get past this mountain pass and come find me in order to find your illustrious \"Metocy.\" Do whatever you can to get past.": "mattias/mattias_my_beloved_trio_i_ve_came_to_tell_you_yo",
