# For godot/scripts/voice_lines.gd. Files are WAV; the game expects MP3 in res://assets/voices/<group>/ (convert first, or hand the zip to Claude).
	"You had called?": "mattias/mattias_you_had_called",
	"*echoing* Impressive, my beloved trio. Come closer…": "mattias/mattias_impressive_my_beloved_trio_come_closer",
	"My beloved trio. I've came to tell you, you must get past this mountain pass and come find me in order to find your illustrious \"Metocy.\" Do whatever you can to get past.": "mattias/mattias_my_beloved_trio_i_ve_came_to_tell_you_yo",
